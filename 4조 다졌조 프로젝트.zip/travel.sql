-- MySQL dump 10.13  Distrib 5.6.45, for Win64 (x86_64)
--
-- Host: localhost    Database: travel
-- ------------------------------------------------------
-- Server version	5.6.45-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `board` (
  `id` varchar(14) DEFAULT NULL,
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(40) DEFAULT NULL,
  `content` varchar(5000) DEFAULT NULL,
  `re_ref` int(11) DEFAULT NULL,
  `re_lev` int(11) DEFAULT NULL,
  `re_seq` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`num`),
  KEY `id` (`id`),
  CONSTRAINT `board_ibfk_1` FOREIGN KEY (`id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `bnum` int(11) DEFAULT NULL,
  `cnum` int(11) NOT NULL AUTO_INCREMENT,
  `c_id` varchar(14) DEFAULT NULL,
  `c_content` varchar(5000) DEFAULT NULL,
  `c_date` datetime DEFAULT NULL,
  PRIMARY KEY (`cnum`),
  KEY `comment_fk` (`bnum`),
  CONSTRAINT `comment_fk` FOREIGN KEY (`bnum`) REFERENCES `review` (`num`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member` (
  `id` varchar(14) NOT NULL,
  `passwd` varchar(20) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `birth` varchar(9) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `phone` int(11) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `address1` varchar(40) DEFAULT NULL,
  `address2` varchar(40) DEFAULT NULL,
  `address3` varchar(40) DEFAULT NULL,
  `address4` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES ('admin','1234','민욱기','940321','jas956@naver.com',1033544363,'jas',NULL,NULL,NULL,NULL),('dajin','ekwls8460*','정다진','19961213','dajin@naver.com',1011111111,'47246',NULL,'부산 부산진구 동천로 109','',' (부전동)'),('nickmo','1234','정닉모','961213','nickmo@naver.com',1011111111,'부산시 기장군',NULL,NULL,NULL,NULL),('YJH90','1234','유정현','900207','YJH90@naver.com',10,'부산광역시 북구 만덕동 휴먼시아3동',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notice` (
  `id` varchar(14) DEFAULT NULL,
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(40) DEFAULT NULL,
  `content` varchar(5000) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `count` int(100) DEFAULT NULL,
  PRIMARY KEY (`num`),
  KEY `id` (`id`),
  CONSTRAINT `notice_ibfk_1` FOREIGN KEY (`id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` VALUES ('admin',7,'412321','헬로우','2020-07-01',2),('admin',8,'412321','헬로우4','2020-07-01',3),('admin',23,'관리자입니다','너는 정현이형','2020-07-09',4),('admin',25,'다진이바보입니다!!!','아에이오우','2020-07-09',1),('admin',26,'변정우 변정우!!!','점심 뭐먹어','2020-07-09',1),('admin',27,'밥밥밥밥','밥밥 디라라라','2020-07-09',3);
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question` (
  `id` varchar(14) DEFAULT NULL,
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) DEFAULT NULL,
  `title` varchar(40) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `content` varchar(5000) DEFAULT NULL,
  `re_ref` int(11) DEFAULT NULL,
  `re_lev` int(11) DEFAULT NULL,
  `re_seq` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`num`),
  KEY `id` (`id`),
  CONSTRAINT `question_ibfk_1` FOREIGN KEY (`id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservation` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `depplacename` varchar(45) DEFAULT NULL,
  `arrplacename` varchar(45) DEFAULT NULL,
  `reser_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `adultcharge` int(11) DEFAULT NULL,
  `depplandtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `seat` varchar(200) DEFAULT NULL,
  `reser_email` varchar(100) DEFAULT NULL,
  `reser_id` varchar(20) DEFAULT NULL,
  `seat_count` int(11) DEFAULT NULL,
  `traingradename` varchar(45) DEFAULT NULL,
  `trainno` int(11) DEFAULT NULL,
  PRIMARY KEY (`num`),
  KEY `id_idx` (`reser_id`),
  CONSTRAINT `fk` FOREIGN KEY (`reser_id`) REFERENCES `member` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
INSERT INTO `reservation` VALUES (20,'부산','서울','2020-07-27 03:42:35',119600,'2020-07-27 20:20:00','A10 B10 ','nickmo@naver.com','nickmo',2,'KTX',104);
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `review` (
  `id` varchar(14) DEFAULT NULL,
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(40) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `content` varchar(5000) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `pos` int(11) DEFAULT NULL,
  `depte` int(11) DEFAULT NULL,
  `readcount` int(11) DEFAULT NULL,
  `commentcount` int(11) DEFAULT NULL,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tboard`
--

DROP TABLE IF EXISTS `tboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tboard` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(14) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `tour_num` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `readcount` int(11) DEFAULT NULL,
  `img1` varchar(100) DEFAULT NULL,
  `img2` varchar(100) DEFAULT NULL,
  `img3` varchar(100) DEFAULT NULL,
  `img4` varchar(100) DEFAULT NULL,
  `img5` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`num`),
  KEY `member_id_fk_idx` (`id`),
  KEY `tboard_ibfk_1` (`tour_num`),
  CONSTRAINT `member_id_fk` FOREIGN KEY (`id`) REFERENCES `member` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tboard_ibfk_1` FOREIGN KEY (`tour_num`) REFERENCES `tour` (`tour_num`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tboard`
--

LOCK TABLES `tboard` WRITE;
/*!40000 ALTER TABLE `tboard` DISABLE KEYS */;
INSERT INTO `tboard` VALUES (2,'admin','속속들이 강원투어 6코스 산바다쏙투어',202007281,'2020-07-24',2,'(강릉선 KTX,누리로)_대표.jpg','(강릉선 KTX,누리로).jpg',NULL,NULL,NULL),(3,'admin','어서와~ 내장산은 처음이지?',202007291,'2020-07-24',1,'정읍내장산_대표사진.jpg','정읍내장산.jpg',NULL,NULL,NULL),(4,'admin','간절곶 을산고래 바다여행',202007301,'2020-07-24',1,'간절곶바다여행1.jpg','간절곶바다여행2.jpg','간절곶바다여행3.jpg','간절곶바다여행4.jpg','간절곶바다여행5.jpg'),(5,'admin','로맨틱 부산',202008011,'2020-07-24',10,'로맨틱부산1박2일.jpg','부산환상야경투어.jpg',NULL,NULL,NULL),(6,'admin','에코 힐링 투어',202008081,'2020-07-24',5,'에코힐링투어_대표사진.jpg','에코힐링투어.jpg',NULL,NULL,NULL),(7,'admin','전주자유여행+한옥레일바이크',202008111,'2020-07-24',9,'전주자유여행+전주한옥레일바이크(당일)(전라선)_대표.jpg','전주자유여행+전주한옥레일바이크(당일)(전라선).jpg',NULL,NULL,NULL);
/*!40000 ALTER TABLE `tboard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tour`
--

DROP TABLE IF EXISTS `tour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tour` (
  `tour_num` int(11) NOT NULL,
  `tour_name` varchar(50) DEFAULT NULL,
  `start_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  `transport` varchar(50) DEFAULT NULL,
  `stay` varchar(50) DEFAULT NULL,
  `reserv_member` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  PRIMARY KEY (`tour_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tour`
--

LOCK TABLES `tour` WRITE;
/*!40000 ALTER TABLE `tour` DISABLE KEYS */;
INSERT INTO `tour` VALUES (202007221,'여수엑스포 풀패키지','2020-07-21 20:10:00','2020-07-22 14:58:00','KTX702','',2,10900),(202007281,'속속들이 강원투어 6코스 산바다쏙투어','2020-07-27 22:05:00','2020-07-28 12:46:00','KTX846','',0,54800),(202007291,'어서와~ 내장산은 처음이지?','2020-07-28 23:20:00','2020-07-29 12:10:00','KTX811','',0,71200),(202007301,'간절곶 울산고래 바다여행','2020-07-29 15:00:00','2020-07-29 15:00:00','KTX109','',0,104800),(202008011,'로맨틱 부산','2020-07-13 21:40:00','2020-07-15 01:18:00','KTX109','앙코르라마다',0,151800),(202008081,'에코 힐링 투어','2020-08-08 01:10:00','2020-08-08 12:21:00','KTX846','',0,54500),(202008111,'전주자유여행+한옥레일바이크','2020-08-10 23:40:00','2020-08-11 10:31:00','KTX712','',3,64800);
/*!40000 ALTER TABLE `tour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tourreservation`
--

DROP TABLE IF EXISTS `tourreservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tourreservation` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `tour_num` int(11) DEFAULT NULL,
  `tour_name` varchar(50) DEFAULT NULL,
  `start_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `end_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `transport` varchar(50) DEFAULT NULL,
  `stay` varchar(50) DEFAULT NULL,
  `reserv_member` int(11) DEFAULT NULL,
  `reserv_email` varchar(100) DEFAULT NULL,
  `reserv_id` varchar(20) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  PRIMARY KEY (`num`),
  KEY `reservation_fk` (`reserv_id`),
  CONSTRAINT `reservation_fk` FOREIGN KEY (`reserv_id`) REFERENCES `member` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tourreservation`
--

LOCK TABLES `tourreservation` WRITE;
/*!40000 ALTER TABLE `tourreservation` DISABLE KEYS */;
INSERT INTO `tourreservation` VALUES (1,202008111,'전주자유여행+한옥레일바이크','2020-08-10 23:40:00','2020-08-11 10:31:00','KTX712','',3,'nickmo@naver.com','nickmo',194400);
/*!40000 ALTER TABLE `tourreservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wishlist`
--

DROP TABLE IF EXISTS `wishlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wishlist` (
  `wish_num` int(11) NOT NULL AUTO_INCREMENT,
  `tour_num` int(11) DEFAULT NULL,
  `wish_id` varchar(14) DEFAULT NULL,
  PRIMARY KEY (`wish_num`),
  KEY `tour_fk` (`tour_num`),
  KEY `id_fk` (`wish_id`),
  CONSTRAINT `tour_fk` FOREIGN KEY (`tour_num`) REFERENCES `tour` (`tour_num`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wishlist`
--

LOCK TABLES `wishlist` WRITE;
/*!40000 ALTER TABLE `wishlist` DISABLE KEYS */;
INSERT INTO `wishlist` VALUES (9,202008111,'nickmo');
/*!40000 ALTER TABLE `wishlist` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-29 17:43:49
